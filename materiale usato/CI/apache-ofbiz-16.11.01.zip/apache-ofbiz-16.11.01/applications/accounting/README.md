<img src="http://ofbiz.apache.org/images/logo.png" alt="Apache OFBiz" />

# accounting component
This OFBiz component enables organisations use a fully utilised financial accounting solution.

## more information
For more information about this component visit the product page in the OFBiz WIKI, 
which can be found at https://cwiki.apache.org/confluence/pages/viewpage.action?pageId=65143347

## issues
JIRA issues related to this component can be found at https://issues.apache.org/jira/browse/OFBIZ/component/12311146

## commits
Committed revisions can be viewed at http://svn.apache.org/viewvc/ofbiz/trunk/applications/accounting